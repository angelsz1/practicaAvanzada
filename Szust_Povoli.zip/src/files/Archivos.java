package files;

import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

import grafos.Grafo;

public class Archivos {
	public int[] leer(String path, Grafo g) {
		File f = new File(path);
		int[] posIniPosFin = new int[2];
		Scanner sc = null;
		
		try {
			sc = new Scanner(f);
			int cantidadNodos = sc.nextInt();
			g.setMat(cantidadNodos);
			posIniPosFin[0] = sc.nextInt() - 1;
			posIniPosFin[1] = sc.nextInt() - 1;
			sc.nextInt();
			
			while(sc.hasNext()) {
				int from, to, cost;
				from = sc.nextInt() -1;
				to = sc.nextInt() -1;
				cost = sc.nextInt();
				g.addEdge(from, to, cost);
			}
			
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(sc != null) {
				try {
					sc.close();
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		return posIniPosFin;
	}
	
	
	
	public void escribir(String path, String txt) {
		File f = new File(path);
		PrintWriter pw = null;
		
		
		try {
			pw = new PrintWriter(f);
			pw.print(txt);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(pw != null) {
				try {
					pw.close();
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
		
	}
}
