package solucion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

import files.Archivos;
import grafos.Edge;
import grafos.Grafo;
import grafos.Nodo;

public class Solucion {
	private int[] nodIniNodFin;

	public int solution(String pathEntrada, String pathSalida) { //O(A^2)
		Grafo g = new Grafo();
		Archivos arch = new Archivos();
		nodIniNodFin = arch.leer(pathEntrada, g);
		List<Integer> aristasACambiar = new ArrayList<>();
		String resultado = "";



		List<Integer> camino = new ArrayList<>();
		
		int res = dijkstra(g, nodIniNodFin[0], nodIniNodFin[1], camino); //O(A*log(N)

		resultado += res + "\n";
		
		
		//sigo el camino para ver si tengo que dar vuelta
		
		List<Edge> realEdges = g.getREALEdges();
		
		for(int i = 0; i < camino.size() - 1; i++) { //O(A)
			int from = camino.get(i);
			int to = camino.get(i + 1);
			int cost = g.getCost(from, to);
			
			if(!realEdges.contains(new Edge(from, to, cost))) { //O(A)
				aristasACambiar.add(realEdges.indexOf(new Edge(to, from, cost)) + 1);
				resultado += (realEdges.indexOf(new Edge(to, from, cost)) + 1) + " ";
			}
		}
		
		System.out.println(aristasACambiar);
		
		
		
		arch.escribir(pathSalida,resultado);
		return res;
	}

	private int dijkstra(Grafo g, int start, int end, List<Integer> camino) {
		boolean[] visited = new boolean[g.size()];
		int[] distances = new int[g.size()];
		int[] predecesores = new int[g.size()];
		Queue<Nodo> pq = new PriorityQueue<>();
		distances[start] = 0;

		// seteo distancias
		for (int i = 0; i < distances.length; i++) {
			if (i != start) 
				distances[i] = Integer.MAX_VALUE;
			pq.offer(new Nodo(i, distances[i]));
			predecesores[i] = i;
		}
		
		
		while(!pq.isEmpty()) {
			Nodo curNode = pq.poll();
			visited[curNode.number] = true;
			
			List<Edge> edges = g.getEdges(curNode.number);
			
			
			for(Edge e : edges) {
				if(!visited[e.to]) {
					if(distances[e.to] > curNode.cost + e.cost) {
						pq.remove(new Nodo(e.to, distances[e.to]));
						distances[e.to] = curNode.cost + e.cost;
						pq.offer(new Nodo(e.to, distances[e.to]));
						predecesores[e.to] = e.from;
					}
				}
			}
		}
		
		camino.add(end);
		int cur = end;
		while(predecesores[cur] != start) {
			camino.add(predecesores[cur]);
			cur = predecesores[cur];
		}
		
		camino.add(start);
		
		
		Collections.reverse(camino);
		
		return distances[end];
	}
}
