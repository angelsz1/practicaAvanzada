package grafos;

import java.util.Objects;

public class Edge implements Comparable<Edge>{
	public int from, to, cost;

	@Override
	public int compareTo(Edge o) {
		return this.cost - o.cost;
	}

	@Override
	public int hashCode() {
		return Objects.hash(cost, from, to);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Edge other = (Edge) obj;
		return cost == other.cost && from == other.from && to == other.to;
	}

	public Edge(int from, int to, int cost) {
		super();
		this.from = from;
		this.to = to;
		this.cost = cost;
	}
	
	
}
