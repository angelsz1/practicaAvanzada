package grafos;

import java.util.ArrayList;
import java.util.List;

public class Grafo {
	private int[][] matAdj;
	private List<Edge> aristas = new ArrayList<>();
	
	
	public void setMat(int size) {
		matAdj = new int[size][size];
	}
	
	
	public void addEdge(int from, int to, int cost) {
		matAdj[from][to] = cost;
		matAdj[to][from] = cost;
		
		aristas.add(new Edge(from, to, cost));
	}
	public int getCost(int from, int to) {
		return matAdj[from][to];
	}
	
	
	public List<Edge> getEdges(int node){
		int i = node;
		List<Edge> edges = new ArrayList<>();
		
		for(int j = 0; j < size(); j++) {
			if(matAdj[i][j] != 0) {
				edges.add(new Edge(i, j, matAdj[i][j]));
			}
		}
		
		return edges;
	}
	
	public List<Edge> getREALEdges(){
		return aristas;
	}
	
	public int size() {
		return matAdj.length;
	}
	
	
	
}
