package grafos;

import java.util.Objects;

public class Nodo implements Comparable<Nodo> {
	public int number, cost;

	@Override
	public int hashCode() {
		return Objects.hash(cost, number);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Nodo other = (Nodo) obj;
		return cost == other.cost && number == other.number;
	}

	public Nodo(int number, int cost) {
		super();
		this.number = number;
		this.cost = cost;
	}

	@Override
	public int compareTo(Nodo o) {
		return this.cost - o.cost;
	}
}
