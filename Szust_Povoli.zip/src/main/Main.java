package main;

import solucion.Solucion;

public class Main {
	public static void main(String[] args) {
		Solucion s = new Solucion();
		System.out.println(s.solution("src/resources/in/caso_4.in", "src/resources/out/caso_4.out"));
	}
}
